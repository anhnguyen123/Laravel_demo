<div class="footer">
	Footer
</div>